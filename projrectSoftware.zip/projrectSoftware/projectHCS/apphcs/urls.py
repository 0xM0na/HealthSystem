from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),  # URL for the index view
    path("signup/", views.signup, name="signup"),  # Sign-Up page
    path("signin/", views.signin, name="signin"),  # Sign-In page
]


