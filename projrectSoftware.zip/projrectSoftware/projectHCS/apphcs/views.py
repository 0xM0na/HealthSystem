
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login

def index(request):
    return render(request, "index.html")
def signup(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")

        # Check if username already exists
        if User.objects.filter(username=username).exists():
            return render(request, "signup.html", {"error": "اسم المستخدم موجود بالفعل."})

        # Create a new user
        User.objects.create_user(username=username, email=email, password=password)
        return redirect("signin")  # Redirect to Sign-In page after successful registration

    return render(request, "signup.html")
def signin(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        # Authenticate user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("index")  # Redirect to homepage or dashboard
        else:
            return render(request, "signin.html", {"error": "بيانات الاعتماد غير صحيحة."})

    return render(request, "signin.html")




